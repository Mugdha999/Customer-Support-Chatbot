# django-chat

![](./images/screenshot.bmp)

Django Project with [ChatterBot](https://github.com/gunthercox/ChatterBot) as the chatbot. The frontend using VueJS.

Requirements saved in `req.txt`

> pip install -r req.txt

Once you have it running type message into textbox and it will return a message.

