from django.apps import AppConfig


class SiliConfig(AppConfig):
    name = 'sili'
